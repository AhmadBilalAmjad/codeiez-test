function filterUnique(arr) {
  const unique = [];
  for (let i = 0; i < arr.length; i++) {
    const currentItem = arr[i];
    let isUnique = true;
    for (let j = 0; j < unique.length; j++) {
      if (currentItem === unique[j]) {
        isUnique = false;
        break;
      }
    }
    if (isUnique) {
      unique.push(currentItem);
    }
  }
  return unique;
}

const uniqueArr = filterUnique([1, 2, 3, 4, 5, 1, 2, 3, 6]);
console.log(uniqueArr);
