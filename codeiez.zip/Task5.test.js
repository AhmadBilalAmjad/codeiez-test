const reverseString = require('./Task1');

describe('reverseString test case', () => {
  test('should reverse a string', () => {
    const input = 'Codeiez';
    const expectedResult = 'zeiedoC';
    const result = reverseString(input);

    // Assertion
    expect(result).toBe(expectedResult);
  });

  test("should return input string if it is a single character", () => {
    const input = 'A';
    const expectedResult = 'A';
    const result = reverseString(input);

    // Assertion
    expect(result).toBe(expectedResult);
  });

  // Test case: should return undefined for empty or non-string input
  test('should return undefined for empty or non string input', () => {
    let input = '';
    let result = reverseString(input);

    // Assertion
    expect(result).toBe(undefined);

    input = 123;
    result = reverseString(input);

    // Assertion
    expect(result).toBe(undefined);
  });
});