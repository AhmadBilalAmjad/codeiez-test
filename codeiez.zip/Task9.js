function searchBooks() {
  const searchQuery = document.getElementById('searchInput').value;

  try {
    fetch(`https://www.googleapis.com/books/v1/volumes?q=${searchQuery}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        const books = data.items;
        const resultsContainer = document.getElementById('results');
        resultsContainer.innerHTML = '';
        books.forEach(book => {
          console.log({ book })
          const bookTitle = book.volumeInfo.title;
          const authors = book.volumeInfo.authors ? book.volumeInfo.authors.join(', ') : 'Unknown Author';
          const thumbnail = book.volumeInfo.imageLinks ? book.volumeInfo.imageLinks.thumbnail : 'https://via.placeholder.com/150';
          const bookLink = book.volumeInfo.infoLink;

          const bookElement = document.createElement('div');
          bookElement.innerHTML = `
                      <div>
                          <img src="${thumbnail}" alt="${bookTitle}">
                          <br />
                          <a href=${bookLink} target="_blank">View Book</a>
                          <h2>${bookTitle}</h2>
                          <p>Author(s): ${authors}</p>
                      </div>
                  `;
          resultsContainer.appendChild(bookElement);
        });
      })
      .catch(error => console.error('Error fetching books:', error));
  } catch (error) {
    console.error('Error occurred:', error);
  }
}
