class Car {
  constructor(make, model, year) {
    this.make = make;
    this.model = model;
    this.year = year;
  }

  accelerate() {
    console.log(`Sit tight, We are increasing the speed of ${this.make}.`);
  }

  brake() {
    console.log(`Applying brakes to ${this.make}.`);
  }
}

const myCar = new Car('Toyota', 'Corolla', 2021);
myCar.accelerate();
myCar.brake();
