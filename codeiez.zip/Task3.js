export async function fetchUserData() {
  const url = 'https://jsonplaceholder.typicode.com/users/1'
  const response = await fetch(url);

  if (response.ok) {
    // Parse the response as JSON
    const userData = await response.json();

    return userData;
  }
}
