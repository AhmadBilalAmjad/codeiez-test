const reverseString = (string) => {
  if (!string || typeof string !== "string") return;
  if (string.length === 1) return string

  let result = ""
  for (let index = string.length - 1; index >= 0; index--) {
    const letter = string[index];
    result += letter;
  }

  return result
}

reverseString("Codeiez")

module.exports = reverseString;