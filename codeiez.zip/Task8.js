async function fetchUserData() {
  const url = 'https://jsonplaceholder.typicode.com/users/1';

  try {
    const response = await fetch(url);

    if (response.ok) {
      const userData = await response.json();

      return userData;
    } else {
      throw new Error('Failed to fetch user data');
    }
  } catch (error) {
    console.error('An error occurred while fetching user data:', error.message);

    return null;
  }
}

fetchUserData()