function filterUnique(arr) {
  const uniqueSet = new Set();
  const uniqueArray = [];

  for (let i = 0; i < arr.length; i++) {
    const currentItem = arr[i];
    if (!uniqueSet.has(currentItem)) {
      uniqueSet.add(currentItem);
      uniqueArray.push(currentItem);
    }
  }

  return uniqueArray;
}

const uniqueArr = filterUnique([1, 2, 3, 4, 5, 1, 2, 3, 6]);
console.log(uniqueArr);
